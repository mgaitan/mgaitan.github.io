Python a los bifes
==================

 .. image:: img/intro.png
    :align: right

| por Martín Gaitán 
|
| Ingeniería en Computación 
| FCEFyN - UNC
|
| 7 de Octubre de 2010 
| gaitan@gmail.com - |cc-by-nc-sa| 


 .. |cc-by-nc-sa| image:: img/cc.png
    


Qué es y qué no es esta charla
------------------------------ 

NO ES
+++++

* Un curso de Python. 
* Ni siquiera una introducción
* No soy una promotora sexy que vende un software. 

SI ES
+++++

* Un producto de mi subjetividad
* Mis ganas de compartir una herramienta
  que me sirvió para estudiar 
* ... trabajar, aprender y **¡aprobar materias!**


Disclaimer
----------

 .. attention::

    Los ejemplos de software desarrollados por el disertante
    que aquí se mostrarán **YA HAN SIDO APROBADOS** y no 
    se aceptan reclamos.

    Si algo no funciona (cosa muy probable) quéjese con 
    el profesor correspondiente.

    Y arréglelo, es `Software Libre <http://code.google.com/u/gaitan/>`_. 



L@s ingenier@s y la programación
---------------------------------

.. epigraph::
    
    La educación en computación no puede hacer a nadie un experto programador 
    más de lo que el estudio de pinceles y pigmentos pueda hacer a alguien un 
    pintor experto
    
    -- Eric Raymon



Los mitos  (1/2)
-----------------

    * Mito 1: Programar es para los analistas de sistemas y para los nerds
      
      * *"... los ingenieros crean lo que nunca ha sido"* -- Theodore von Kárman

    * Mito 2: Los ingenieros (en computación) necesitamos 
              más C y ASM que lenguajes de (más) alto nivel
      
      * Necesitamos más programación. Ingeniería => ¡ingenio y practicidad!

Los mitos  (2/2)
-----------------

    * Mito 3: Si sabés programar, no importa el lenguaje en el que programes 

      * *"Un lenguaje que no afecte tu manera de pensar la programación, no merece conocerse"* -- Alan Perlis 

    * Mito 4: Los lenguajes interpretados no son eficientes
        
      * El bottleneck de la eficiencia es el programador
   

A todo esto, ¿Qué es Python?
-----------------------------

.. epigraph::
    
    El canónico *"Python es un gran primer lenguaje"* suscitó 
    *"¡Python es un gran último lenguaje!"*

    -- Noah Spurrier


En serio, qué es Python ?
---------------------------

.. image:: img/python-powered.png
   :align: right

* Un lenguaje de alto nivel

    * (muy) Fácil de aprender
    * con sintáxis legible y expresiva
    * Multiparadigma
    * Dinámico
    * Fuertemente tipado
    * Interpretado 
    * Interactivo
    * Extensible
    * Multiplataforma
    * Libre y Gratis
    * Con las baterías incluídas
    * Con gran documentación
    * y una maravillosa comunidad de usuarios


Importate esta
---------------

El Zen de Python
+++++++++++++++++
  
  ::

    Bello es mejor que feo.
    Explícito es mejor que implícito.
    Simple es mejor que complejo.
    Complejo es mejor que complicado.
    Plano es mejor que anidado.
    Espaciado es mejor que denso.
    La legibilidad cuenta.
    Los casos especiales no son tan especiales como para quebrar las reglas.
    Aunque lo práctico le gana a la pureza (...)
 
sigue en ... ::  

     >>> import this

   

Python para ciencia e ingeniería (1/2)
---------------------------------------

Con ustedes, el *dreamteam*:

    * Numpy

        * Extensión para cálculo numérico (vectores n-dimensionales)
        * Es C envuelto en Python. ¡Rápido!

    * Scipy

        * Paquete de algoritmos *sobre los hombros del gigante* NumPy
        * FFT, interpolación, regresión, integración, ODEs, álgebra, estadística, 
          señales, optimización, tratamiento de imágenes, y mucho más... uff!

Python para ciencia e ingeniería (2/2)
---------------------------------------

    * Matplotlib

        * Biblioteca de graficación 2D y 3D
        * API similiar a Matlab (pero Pythónica)
        * Incrustable en tus propios programas

    * IPython

        * Un intérprete interactivo potenciado
        * Más? Viernes 15/10 10hs en la Universidad IES-SIGLO XXI
    
    * Y obviamente: café + ganas de aprender y divertirse

¿Quién usa Python?
-------------------

    * Google 
    * Yahoo
    * Nasa
    * Dreamworks
    * Canonical
    * Cientos de laboratorios de investigación del mundo
    * Martín Gaitán
    * y algunos otros ... 


¡Basta Gaitán! mostrá los ejemplos
-----------------------------------
 
   .. image:: img/enlacancha.jpg
      :align: center
      :width: 90 %
 
 

Algoritmos / Paradigmas 
------------------------

 +---------------------------------------------+-------------------------------------------+
 | El archifamoso "Simulador de red".          |  Y un ejemplo "físico" que                |
 | (Wolfmann cambiá el práctico!)              |  usa PyODE (simulación de cuerpo rígido)  |
 | Usa NetworkX, librería para estudiar        |  y PyGame                                 |
 | grafos y redes                              |                                           |  
 |                                             |                                           |
 |  .. image:: img/pynetsim.png                |    .. image:: img/ejemplo-pyode.png       |
 |     :width: 450px                           |       :width: 450px                       |
 |                                             |                                           |
 |                                             |                                           |
 +---------------------------------------------+-------------------------------------------+

Programación concurrente
-------------------------

 +---------------------------------------------+-------------------------------------------+
 | El problema del barbero durmiente.          |  Y el de los filósofos.                   | 
 |                                             |                                           |
 |  * Módulo Threading (incluído)              |  * más fachero                            |
 |  * Usa semáforos (con S)                    |  * lo encontré por ahí ;-)                |
 |  * ~100 líneas de código                    |                                           |
 |  * ¡Se entiende el algoritmo!               |  .. image:: img/filosofos.png             |
 |  * Lo hice para compararla con Java         |     :width: 500px                         |
 |                                             |                                           |
 +---------------------------------------------+-------------------------------------------+


Sistemas operativos II (1/2)
-----------------------------

Esquédulin 
+++++++++++

 .. image:: img/esquedulin.png
    :align: right

Un programa para estudiar (e inventar) algoritmos de planificación de corto plazo
    
 * Usa wxPython y Matplolib
 * Dos semanas de desarrollo. Gran "inversión" para la tesis. 
 * ¡Introspección!

Sistemas operativos II (2/2)
-----------------------------

 * Totalmente extensible. Ejemplo completo ::

    class SRT(Algorithm):
        """Shortest remaining time algorithm"""

        def __init__(self, procesos=None):
            Algorithm.__init__(self,procesos)
            self.short_name = u'SRT'
            self.long_name = u'Shortest remaining time'
            self.description = self.__doc__
            self.preferent = True               

        def selection_function(self, x, y):
            if x.remaining_time < y.remaining_time:
                return -1
            if x.remaining_time == y.remaining_time:
                return 0
            if x.remaining_time > y.remaining_time:
                return 1

Sistemas de computación (1/3)
-----------------------------
 
FPUInspector
++++++++++++

 * Nada de "simular", ¡Vamos al silicio!
 * *Menage trois*:  Python <-> C <-> ASM

 .. image:: img/fpuinspector.png
    :align: center



Sistemas de computación (2/3)
-------------------------------

ctypes: para JNI que lo mira por TV
++++++++++++++++++++++++++++++++++++

  ==========================  ==================================================
     JNI                       ctypes
  ==========================  ==================================================
    .. image:: img/jni.gif       ::
       
                                    import platform
                                    from ctypes import *        # Magia pura

                                    so = platform.system()

                                    if so == 'Linux':
                                        lib = cdll.LoadLibrary('libfpu.so') 
                                    elif so == 'Windows':
                                        lib = cdll.WinDLL('libfpu.dll') 
                        
                               

  ==========================  ==================================================

Sistemas de computación (3/3)
-----------------------------

El problemón
++++++++++++

   .. image:: img/arquitectura_fpuinspector.png
      :align: right

  * La FPU se usa para otras cosas

La solución(ona)
++++++++++++++++

 * Que el SO se encargue de la parte sucia (para eso está)
 * Separo mi "cuentas" en otro proceso
 * Fácil gracias al módulo ``multiprocessing`` (¡cuanta magia!)
    
    

Proyecto integrador 1/2
------------------------

GPEC 2010
+++++++++

  .. image:: img/gpec.png
     :height: 550px
     :align: right
 
  * Un software que hace dibujitos que le gustan a l@s químic@s


Proyecto integrador (2/2)
--------------------------

  * Mozo, lo de siempre: wxpython, numpy, matplotlib
  * Pub/Sub: ¡vivan los desacoples!
  * Costo: 

    * Cocomo dice: 3 personas/año - u$s 150mil
    * Yo digo: Python, 5 meses y muchas ganas de recibirse. 

    .. image:: img/cost. png
       :align: center

Y qué más?
------------

  * Cálculo simbólico: simpy
  * Redes: protocolos de bajo y alto nivel
  * Electrónica: control de puertos, frameworks para robótica
  * Modelos y simulación: simpy (otro)
  * Embebidos: Nokia, Maebo, Android ...  
  * Hardware: MyHDL (¡grandioso!)
  * Pulentez: MPI, scipy.cluster, PyCuda
  * Base de datos: relacionales, ORM, objetos, distribuídas
  * Juegos: 2d, 3d, opengl, caseros, profesionales
  * Escribir documentación/papers/tesis: restructuredText
  * Web !
  * y +++
  
Chivos
-------

  .. image:: img/chivo.png
     :align: left

  * Tutorial: en la biblio de la facu y en http://tutorialpython.com.ar 

  * PyAr: `www.python.org.ar <http:/www.python.org.ar>`_

  * Conferencias Python Argentina 2010 **¡en Córdoba!**
     
    * viernes 15 y sábado 16 de octubre
    * Universidad Siglo XXI - Nueva Córdoba
    * http://ar.pycon.org/2010


Preguntas
----------

    .. image:: img/questions.jpg
       :align: center


Gracias¹ (o perdón) a tod@s
-------------------------------

Aplausos vs. Chiflidos

    .. image:: img/vs.gif
       :align: center

    .. container:: custom

       ¹ aunque sé que vienieron por el pendrive


  

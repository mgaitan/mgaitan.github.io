<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://www.spip.net/trad-lang/
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	'title' => 'Disqus',
	'description' => 'Disqus comment platform for SPIP',
	'configuration' => 'Configuration variables', 
	'disqus_shortname' => 'Disqus shortname',
	'disqus_shortname_explication' => 'To install Disqus, you will need to know your forum shortname as registered on <a href="http://disqus.com">Disqus</a>',


);

?>

<?php

if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
    'adjuntar_imagenes' => 'Adjuntar im&aacute;genes',
	// B
	'buscar_en_picasa' => 'Buscar en Picasa'

	// D

	// E

	// F

	// H

	// I

	// L

	// M

	// N

	// P

	// R

	// S

	// T

	// U

	// V
);

?>
